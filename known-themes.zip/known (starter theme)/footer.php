<?php
/**
 * The template for displaying the footer
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 * @package KNOWN
 */

?>

        </section><!-- /#mstr-cntnt -->

        <footer id="mstr-ftr" class="mstr-ftr">
            <div class="ste-ftr">
                <p class="credits col-md-4"><a href="http://knowndesign.co" target="_blank">Website design by</a> <strong>KNOWN</strong></p>
            </div>
        </footer>
    <?php wp_footer(); ?>
</body>
</html>
