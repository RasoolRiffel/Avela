<?php
/**
 * KNOWN Custom Taxonomies
 *
 * @link https://codex.wordpress.org/Function_Reference/register_taxonomy
 * @package KNOWN
 */

/*
 * Taxonomy
 */

?>