<?php
/**
 * KNOWN Custom Post Types
 *
 * @link https://codex.wordpress.org/Function_Reference/register_post_type
 * @package KNOWN
 */

/*
 * Post Type
 */

?>