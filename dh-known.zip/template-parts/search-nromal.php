

<div class="pge-sctn indx-hntry wth-sdbr">
    
    <?php

    echo '<h1 class="pst-ttl text-center">Search Results</h1>';

    get_template_part( 'template-parts/content', 'blog' );

     ?>
     
</div>
